<?php
namespace Ciencia360\Repositories;

use Ciencia360\Config\Database;

class ArticleRepository
{
    public function list(array $filters, int $limit, int $offset): array
    {
        $pdo = Database::pdo();
        $sql = "SELECT * FROM articulos WHERE 1=1";
        $params = [];

        if (!empty($filters['tema'])) {
            $sql .= " AND tema = ?";
            $params[] = $filters['tema'];
        }
        if (!empty($filters['q'])) {
            $sql .= " AND titulo LIKE ?";
            $params[] = "%" . $filters['q'] . "%";
        }

        $sql .= ($filters['orden'] ?? 'recientes') === 'populares'
            ? " ORDER BY visitas DESC, fecha_publicacion DESC"
            : " ORDER BY fecha_publicacion DESC";

        $sql .= " LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;

        $st = $pdo->prepare($sql);
        $st->execute($params);
        return $st->fetchAll();
    }

    public function count(array $filters): int
    {
        $pdo = Database::pdo();
        $sql = "SELECT COUNT(*) FROM articulos WHERE 1=1";
        $params = [];

        if (!empty($filters['tema'])) {
            $sql .= " AND tema = ?";
            $params[] = $filters['tema'];
        }
        if (!empty($filters['q'])) {
            $sql .= " AND titulo LIKE ?";
            $params[] = "%" . $filters['q'] . "%";
        }

        $st = $pdo->prepare($sql);
        $st->execute($params);
        return (int) $st->fetchColumn();
    }

    public function findBySlug(string $slug): ?array
    {
        $pdo = Database::pdo();
        $st = $pdo->prepare("SELECT * FROM articulos WHERE slug = ? LIMIT 1");
        $st->execute([$slug]);
        $row = $st->fetch();
        return $row ?: null;
    }

    public function incrementViews(int $id): void
    {
        $pdo = Database::pdo();
        $pdo->prepare("UPDATE articulos SET visitas = visitas + 1 WHERE id = ?")->execute([$id]);
    }

    public function related(string $tema, string $excludeSlug, int $limit = 3): array
    {
        $pdo = Database::pdo();
        $st = $pdo->prepare("SELECT slug, titulo, imagen FROM articulos
                             WHERE tema = ? AND slug <> ?
                             ORDER BY fecha_publicacion DESC LIMIT ?");
        $st->execute([$tema, $excludeSlug, $limit]);
        return $st->fetchAll();
    }
}
