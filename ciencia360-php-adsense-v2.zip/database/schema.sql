CREATE TABLE IF NOT EXISTS articulos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(200) UNIQUE NOT NULL,
  titulo VARCHAR(255) NOT NULL,
  resumen TEXT NULL,
  contenido LONGTEXT NULL,
  imagen VARCHAR(255) NULL,
  tema ENUM('ciencia-tecnologia','medio-ambiente','salud-biologia','espacio-futuro') NOT NULL,
  autor VARCHAR(120) NULL,
  fecha_publicacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  visitas INT NOT NULL DEFAULT 0,
  INDEX idx_tema (tema),
  INDEX idx_fecha (fecha_publicacion),
  INDEX idx_visitas (visitas)
);
