<?php
// Redirige al listado de artículos
header("Location: articulos.php");
exit;
