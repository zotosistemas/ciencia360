<?php
require __DIR__ . '/../vendor/autoload.php';

use Ciencia360\Config\Config;
use Ciencia360\Repositories\ArticleRepository;
use Ciencia360\Services\ArticleService;

Config::load(__DIR__ . '/../config/.env');

$slug = $_GET['slug'] ?? '';
if (!$slug) { header('Location: articulos.php'); exit; }

$service = new ArticleService(new ArticleRepository());
$art = $service->detailBySlug($slug);
if (!$art) { http_response_code(404); echo 'Artículo no encontrado.'; exit; }

$title = $art['titulo'] . ' | Ciencia360';
$metaDescription = $art['resumen'] ?? '';

// AdSense blocks prepared here (replace data-ad-slot with your IDs)
$adsClient = \Ciencia360\Config\Config::get('ADSENSE_CLIENT', '');
$adInArticle = '';
$adInArticle2 = '';
$adSidebar = '';
$adDisplayEnd = '';

if (!empty($adsClient)) {
  // In-article 1 (después del 2º párrafo)
  $adInArticle = <<<HTML
  <div class="my-4 ad-slot text-center">
    <ins class="adsbygoogle"
         style="display:block; text-align:center;"
         data-ad-client="{$adsClient}"
         data-ad-slot="1234567890"   <!-- REEMPLAZA con tu slot -->
         data-ad-format="fluid"
         data-ad-layout="in-article"></ins>
    <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
  </div>
  HTML;

  // In-article 2 (después del 5º párrafo)
  $adInArticle2 = <<<HTML
  <div class="my-4 ad-slot text-center">
    <ins class="adsbygoogle"
         style="display:block; text-align:center;"
         data-ad-client="{$adsClient}"
         data-ad-slot="2234567890"   <!-- REEMPLAZA con tu slot -->
         data-ad-format="fluid"
         data-ad-layout="in-article"></ins>
    <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
  </div>
  HTML;

  // Sidebar (300x600 responsivo)
  $adSidebar = <<<HTML
  <div class="ad-slot-sidebar">
    <ins class="adsbygoogle"
         style="display:block"
         data-ad-client="{$adsClient}"
         data-ad-slot="3234567890"   <!-- REEMPLAZA con tu slot -->
         data-ad-format="auto"
         data-full-width-responsive="false"></ins>
    <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
  </div>
  HTML;

  // Display al final
  $adDisplayEnd = <<<HTML
  <div class="my-4 ad-slot text-center">
    <ins class="adsbygoogle"
         style="display:block"
         data-ad-client="{$adsClient}"
         data-ad-slot="0987654321"   <!-- REEMPLAZA con tu slot -->
         data-ad-format="auto"
         data-full-width-responsive="true"></ins>
    <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
  </div>
  HTML;
}

include __DIR__ . '/../views/layout/head.php';
include __DIR__ . '/../views/layout/header.php';
include __DIR__ . '/../views/article/detail.php';
include __DIR__ . '/../views/layout/footer.php';
